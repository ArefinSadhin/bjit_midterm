package com.sadhin.news.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
@Entity(tableName = "bookmark",indices = [Index(value = ["url"], unique = true)])
class BookMark (
    @PrimaryKey(autoGenerate = true)
    val id: Int,
    val author: String?,
    val content: String?,
    val description: String?,
    val publishedAt: String?,
    val source: Source,
    val title: String?,
    @ColumnInfo(name = "url")
    val url: String?,
    val urlToImage: String?
){}