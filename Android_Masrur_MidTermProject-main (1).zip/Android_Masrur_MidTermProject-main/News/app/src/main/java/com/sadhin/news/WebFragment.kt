package com.sadhin.news

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.sadhin.news.databinding.FragmentWebBinding
import androidx.navigation.fragment.navArgs
import android.webkit.WebViewClient

class WebFragment : Fragment() {
    private var _binding:FragmentWebBinding? = null
    private val binding get() = _binding!!
    private val navArgs:WebFragmentArgs by navArgs()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_web, container, false)
        _binding= FragmentWebBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navArgs.url?.let {
            binding.webView.webViewClient = WebViewClient()
            binding.webView.loadUrl(it)
            binding.webView.settings.javaScriptEnabled = true
            binding.webView.settings.setSupportZoom(true)
        }

    }

    companion object {
    }
}