package com.sadhin.news.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.sadhin.news.model.BookMark
import com.sadhin.news.model.NewsArticle

@Dao
interface NewsDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addAllNews(allNews:List<NewsArticle>)

    @Query("select * from news")
    fun getAllNews():LiveData<List<NewsArticle>>

    @Query("select * from news where category =:id")
    fun getAllNewsCategory(id: String): List<NewsArticle>

    @Query("DELETE FROM news")
    suspend fun deleteAllNews()

    @Query ("SELECT COUNT(*) FROM news WHERE category = :category ")
    fun categoryCount(category: String):Int

//    @Query("select count(*) from bookmark where url = :url")
//    fun bookmarkExist(url:String):Int
//    @Query(" ")
//    suspend fun deleteDuplicateBookmark()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addBookmark(bookmark: BookMark)

//    @Query("  ")
//    suspend fun addBookmark(bookmark: BookMark)

    @Query("select * from bookmark")
    fun getAllBookmarks():LiveData<List<BookMark>>

    @Delete
    suspend fun deleteBookmark(bookmark: BookMark)



}