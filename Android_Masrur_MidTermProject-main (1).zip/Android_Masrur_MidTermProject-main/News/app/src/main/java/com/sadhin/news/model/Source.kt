package com.sadhin.news.model

data class Source(
    val id: String?,
    val name: String?
)