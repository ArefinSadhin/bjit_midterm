package com.sadhin.news

import android.os.Bundle
import android.util.Log
import android.view.*
import androidx.fragment.app.Fragment
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.tabs.TabLayout
import com.sadhin.news.databinding.FragmentHomeBinding
import com.sadhin.news.viewmodel.NewsViewModel
import androidx.lifecycle.ViewModelProvider

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: NewsViewModel by viewModels()
    private lateinit var recyclerView: RecyclerView
    private var state= "NEWS"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
//        return inflater.inflate(R.layout.fragment_home, container, false)
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        setHasOptionsMenu(true)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val adapter= NewsAdapter(requireContext(),viewModel)
        recyclerView=binding.recyclerViewNews
        recyclerView.layoutManager=LinearLayoutManager(context)
        recyclerView.adapter=adapter



        val tabLayout = binding.tabLayout
        tabLayout.addTab(tabLayout.newTab().setText("NEWS"))
        tabLayout.addTab(tabLayout.newTab().setText("TOP NEWS"))
        tabLayout.addTab(tabLayout.newTab().setText(GENERAL))
        tabLayout.addTab(tabLayout.newTab().setText(BUSINESS))
        tabLayout.addTab(tabLayout.newTab().setText(ENTERTAINMENT))
        tabLayout.addTab(tabLayout.newTab().setText(TECHNOLOGY))
        tabLayout.addTab(tabLayout.newTab().setText(HEALTH))
        tabLayout.addTab(tabLayout.newTab().setText(SPORTS))

        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {

                when (tab.position) {
                    0->{
                        state="NEWS"
                    }
                    1 -> {
                        viewModel.setList(TOP_NEWS)
                        state= TOP_NEWS
                    }
                    2 -> {
                        viewModel.setList(GENERAL)
                        state= GENERAL
                    }
                    3 -> {
                        viewModel.setList(BUSINESS)
                        state= BUSINESS
                    }
                    4 -> {
                        viewModel.setList(ENTERTAINMENT)
                        state= ENTERTAINMENT
                    }
                    5 -> {
                        viewModel.setList(TECHNOLOGY)
                        state= TECHNOLOGY
                    }
                    6 -> {
                        viewModel.setList(HEALTH)
                        state= HEALTH
                    }
                    7 -> {
                        viewModel.setList(SPORTS)
                        state= SPORTS
                    }
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })

        viewModel.news.observe(viewLifecycleOwner) { if (state == "NEWS"){adapter.setData(it)} }
        viewModel.category.observe(viewLifecycleOwner) { if(state!= "NEWS"){adapter.setData(it)} }

        binding.swipe.setOnRefreshListener {
            viewModel.deleteAllArticle()
            viewModel.initialLoad()
            Toast.makeText(requireContext(), "Refreshed", Toast.LENGTH_SHORT).show()
            binding.swipe.isRefreshing=false
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.search, menu)
        val searchView = menu.findItem(R.id.search_bar)?.actionView as SearchView

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {
                if(state!="NEWS"){ viewModel.searchNews(query.toString()) }
                
                return false
            }
            override fun onQueryTextChange(newText: String): Boolean {
                if(newText.isEmpty()){
                    viewModel.setList(state)
                }
                return true
            }

        })
        super.onCreateOptionsMenu(menu, inflater)
    }



    companion object {
        const val TOP_NEWS = "top_news"
        const val GENERAL = "general"
        const val BUSINESS = "business"
        const val ENTERTAINMENT = "entertainment"
        const val SPORTS = "sports"
        const val HEALTH = "health"
        const val TECHNOLOGY = "technology"
    }
}
