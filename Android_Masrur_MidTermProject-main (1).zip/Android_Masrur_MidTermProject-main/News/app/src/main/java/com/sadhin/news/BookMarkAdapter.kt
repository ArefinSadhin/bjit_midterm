package com.sadhin.news

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sadhin.news.model.BookMark
import com.sadhin.news.viewmodel.BookMarkViewModel
import com.sadhin.news.viewmodel.NewsViewModel


class BookMarkAdapter(
    private val context: Context,
    private val viewModel: BookMarkViewModel
) : RecyclerView.Adapter<BookMarkAdapter.ItemViewHolder>() {
    private var listOfBookMark= emptyList<BookMark>()

    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.title_bookmark)
        val image: ImageView = view.findViewById(R.id.image_bookmark)
        val description: TextView = view.findViewById(R.id.description_bookmark)
        val date: TextView = view.findViewById(R.id.date_bookmark)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val layout= LayoutInflater.from(context).inflate(R.layout.bookmark,parent,false)
        return ItemViewHolder(layout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val pos=listOfBookMark[position]
        holder.title.text = pos.title
        holder.description.text = pos.description
        holder.date.text = pos.publishedAt

        Glide.with(holder.itemView.context)
            .load(pos.urlToImage)
            .placeholder(R.drawable.ic_launcher_foreground)
            .into(holder.image)

        holder.itemView.setOnLongClickListener {
            viewModel.deleteBookmark(pos)
            Toast.makeText(context, "Removed", Toast.LENGTH_SHORT).show()
            true
        }
        holder.title.setOnClickListener{
            val action=BookMarkFragmentDirections.actionBookMarkFragmentToWebFragment(pos.url)
            holder.itemView.findNavController().navigate(action)
        }
    }

    override fun getItemCount(): Int { return listOfBookMark.size }

    fun setData(news:List<BookMark>){ listOfBookMark=emptyList()
        listOfBookMark=news
        notifyDataSetChanged()
    }

}