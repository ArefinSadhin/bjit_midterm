package com.sadhin.news.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.sadhin.news.Constant
import com.sadhin.news.NewsAdapter
import com.sadhin.news.dao.NewsDatabase
import com.sadhin.news.model.BookMark
import com.sadhin.news.model.News
import com.sadhin.news.model.NewsArticle
import com.sadhin.news.network.NewsApi
import com.sadhin.news.respority.NewsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*


class NewsViewModel(application: Application): AndroidViewModel(application) {
    val news:LiveData<List<NewsArticle>>
    private val temp = MutableLiveData<List<NewsArticle>>()
    val category:LiveData<List<NewsArticle>> = temp

    private val repository: NewsRepository

    init {
        repository = NewsRepository(NewsDatabase.getDatabase(application).NewsDao())
        deleteAllArticle()
        initialLoad()
        news=repository.getAllArticle
    }

    fun setList(category: String){
        viewModelScope.launch (Dispatchers.IO){
            temp.postValue(repository.getListCategory(category))
        }
    }


    fun initialLoad() {
        loadTopNews()
        loadNewsByCategory(Constant.GENERAL)
        loadNewsByCategory(Constant.BUSINESS)
        loadNewsByCategory(Constant.ENTERTAINMENT)
        loadNewsByCategory(Constant.SPORTS)
        loadNewsByCategory(Constant.HEALTH)
        loadNewsByCategory(Constant.TECHNOLOGY)
    }

    private fun loadNewsByCategory(category:String){
        viewModelScope.launch {
            val newsArticle =Constant.articleToNewsArticle(NewsApi.retrofitService.getNewsByCategory(category).articles,category)
            repository.addAllNewsArticles(newsArticle)
        }

    }
    private fun loadTopNews(){
        viewModelScope.launch  {
            val newsArticle =Constant.articleToNewsArticle(NewsApi.retrofitService.getTopNews().articles,Constant.TOP_NEWS)
            repository.addAllNewsArticles(newsArticle)
        }
    }

    fun deleteAllArticle(){
        viewModelScope.launch(Dispatchers.IO) {repository.deleteAllNewsArticle()  }
    }

    fun addBookMark(news:NewsArticle){
        viewModelScope.launch ( Dispatchers.IO ){ repository.addBookMark(Constant.newsArticleToBookMark(news)) }
    }
    fun searchNews(text:String){
        var list:List<NewsArticle> = temp.value!!
        val result = mutableListOf<NewsArticle>()
        for(i in list){
            if(i.title!!.lowercase(Locale.ROOT).contains(text.lowercase(Locale.ROOT)))
            {
                result.add(i)
            }
        }
        temp.value = result
    }
/*    fun deleteDuplicateBookmark(category: String){
        viewModelScope.launch (Dispatchers.IO){
            repository.
        }
    }*/
}

